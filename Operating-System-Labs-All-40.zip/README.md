# Operating-System-

## Lab Experiments

| Folder | Experiment |
|--------|------------|
| [Lab-01](Lab-01) | Create a new process by invoking the appropriate system call. Get the process identifier of the currently running process and its respective parent using system calls and display the same using a C program. |
| [Lab-02](Lab-02) | Identify the system calls to copy the content of one file to another and illustrate the same using a C program. |
| [Lab-03](Lab-03) | Design a CPU scheduling program with C using First Come First Served technique with the following considerations: (a) All processes are activated at time 0. (b) Assume that no process waits on I/O devices. |
| [Lab-04](Lab-04) | Construct a scheduling program with C that selects the waiting process with the smallest execution time to execute next. |
| [Lab-05](Lab-05) | Construct a scheduling program with C that selects the waiting process with the highest priority to execute next. |
| [Lab-06](Lab-06) | Construct a C program to implement preemptive priority scheduling algorithm. |
| [Lab-07](Lab-07) | Construct a C program to implement a non-preemptive SJF algorithm. |
| [Lab-08](Lab-08) | Construct a C program to simulate Round Robin scheduling algorithm with C. |
| [Lab-09](Lab-09) | Illustrate the concept of inter-process communication using shared memory with a C program. |
| [Lab-10](Lab-10) | Illustrate the concept of inter-process communication using message queue with a C program. |
| [Lab-11](Lab-11) | Illustrate the concept of multithreading using a C program. |
| [Lab-12](Lab-12) | Design a C program to simulate the concept of Dining-Philosophers problem. |
| [Lab-13](Lab-13) | Construct a C program for implementation of the various memory allocation strategies. |
| [Lab-14](Lab-14) | Construct a C program to organise the file using a single level directory. |
| [Lab-15](Lab-15) | Design a C program to organise the file using a two level directory structure. |
| [Lab-16](Lab-16) | Develop a C program for implementing random access file for processing the employee details. |
| [Lab-17](Lab-17) | Illustrate the deadlock avoidance concept by simulating Banker's algorithm with C. |
| [Lab-18](Lab-18) | Construct a C program to simulate producer-consumer problem using semaphores. |
| [Lab-19](Lab-19) | Design a C program to implement process synchronization using mutex locks. |
| [Lab-20](Lab-20) | Construct a C program to simulate Reader-Writer problem using Semaphores. |
| [Lab-21](Lab-21) | Develop a C program to implement worst fit algorithm of memory management. |
| [Lab-22](Lab-22) | Construct a C program to implement best fit algorithm of memory management. |
| [Lab-23](Lab-23) | Construct a C program to implement first fit algorithm of memory management. |
| [Lab-24](Lab-24) | Design a C program to demonstrate UNIX system calls for file management. |
| [Lab-25](Lab-25) | Construct a C program to implement the I/O system calls of UNIX (fcntl, seek, stat, opendir, readdir). |
| [Lab-26](Lab-26) | Construct a C program to implement the file management operations. |
| [Lab-27](Lab-27) | Develop a C program for simulating the function of ls UNIX Command. |
| [Lab-28](Lab-28) | Write a C program for simulation of GREP UNIX command. |
| [Lab-29](Lab-29) | Write a C program to simulate the solution of Classical Process Synchronization Problem. |
| [Lab-30](Lab-30) | Write C programs to demonstrate the following thread related concepts: (i) create (ii) join (iii) equal (iv) exit. |
| [Lab-31](Lab-31) | Construct a C program to simulate the First in First Out paging technique of memory management. |
| [Lab-32](Lab-32) | Construct a C program to simulate the Least Recently Used paging technique of memory management. |
| [Lab-33](Lab-33) | Construct a C program to simulate the optimal paging technique of memory management. |
| [Lab-34](Lab-34) | Consider a file system where the records of the file are stored one after another both physically and logically. A record of the file can only be accessed by reading all the previous records. Design a C program to simulate the file allocation strategy. |
| [Lab-35](Lab-35) | Consider a file system that brings all the file pointers together into an index block. The ith entry in the index block points to the ith block of the file. Design a C program to simulate the file allocation strategy. |
| [Lab-36](Lab-36) | With linked allocation, each file is a linked list of disk blocks; the disk blocks may be scattered anywhere on the disk. The directory contains a pointer to the first and last blocks of the file. Each block contains a pointer to the next block. Design a C program to simulate the file allocation strategy. |
| [Lab-37](Lab-37) | Construct a C program to simulate the First Come First Served disk scheduling algorithm. |
| [Lab-38](Lab-38) | Design a C program to simulate SCAN disk scheduling algorithm. |
| [Lab-39](Lab-39) | Develop a C program to simulate C-SCAN disk scheduling algorithm. |
| [Lab-40](Lab-40) | Illustrate the various File Access Permission and different types of users in Linux. |
