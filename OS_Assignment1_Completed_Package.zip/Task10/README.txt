Task 10 evidence folder. Add your terminal output, screenshots and any additional scripts/configuration required by the assignment.
Source: process_thread_bench.c
