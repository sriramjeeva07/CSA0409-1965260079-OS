#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <sys/wait.h>
#include <pthread.h>

#define N 1000

static double now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec * 1000.0 + (double)ts.tv_nsec / 1e6;
}
static void *thread_fn(void *arg) {
    (void)arg;
    return NULL;
}
int main(void) {
    double start = now_ms();
    int made = 0;
    for (int i = 0; i < N; i++) {
        pid_t p = fork();
        if (p < 0) { perror("fork"); break; }
        if (p == 0) _exit(0);
        if (waitpid(p, NULL, 0) < 0) { perror("waitpid"); return 1; }
        made++;
    }
    double proc_ms = now_ms() - start;
    printf("processes: %d created and waited, elapsed %.3f ms\n", made, proc_ms);

    pthread_t threads[N];
    start = now_ms();
    int tmade = 0;
    for (int i = 0; i < N; i++) {
        int rc = pthread_create(&threads[i], NULL, thread_fn, NULL);
        if (rc != 0) { fprintf(stderr, "pthread_create failed at %d (error %d)\n", i, rc); break; }
        tmade++;
    }
    for (int i = 0; i < tmade; i++) {
        int rc = pthread_join(threads[i], NULL);
        if (rc != 0) { fprintf(stderr, "pthread_join error %d\n", rc); return 1; }
    }
    double thread_ms = now_ms() - start;
    printf("threads:   %d created and joined, elapsed %.3f ms\n", tmade, thread_ms);
    return (made == N && tmade == N) ? 0 : 2;
}
