Task 4 evidence folder. Add your terminal output, screenshots and any additional scripts/configuration required by the assignment.
