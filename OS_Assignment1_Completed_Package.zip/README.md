# CSA04 Operating Systems Assignment 1

Student name: ______________________
Register number: ___________________
GitHub repository: `CSA04-<RegisterNumber>-Assignment1`

## Environment used to prepare and test
- Linux: Debian GNU/Linux 13 (container environment)
- Compiler: GCC 14.2.0
- Architecture: x86_64
- Note: Re-run all measurements on your own Linux system and insert your own outputs in the report. `strace` was not available in the preparation environment.

## Compile and run
```bash
gcc -std=c11 -Wall -Wextra -O2 Task06/copy_file.c -o Task06/copy_file
./Task06/copy_file

gcc -std=c11 -Wall -Wextra -O2 Task07/process_shell.c -o Task07/process_shell
./Task07/process_shell

gcc -std=c11 -Wall -Wextra -O2 -pthread Task10/process_thread_bench.c -o Task10/process_thread_bench
./Task10/process_thread_bench
```

## Expected Task 6 output
```text
buffer    1 bytes: 10001 read() calls
buffer  512 bytes:    21 read() calls
buffer 4096 bytes:     4 read() calls
```

## Task 7 expected output
```text
shell: running job 1
42
job 1 exit status 0
shell: running job 2
job 2 exit status 3
```

## Measurement commands
```bash
strace -c -e read,write ./Task06/copy_file
/usr/bin/time -v ./Task06/copy_file
./Task10/process_thread_bench
```
If `strace` is missing, install it using your distribution's package manager or use an available lab Linux machine. Save terminal screenshots in the corresponding task folders.

## GitHub submission checklist
- Create repository `CSA04-<RegisterNumber>-Assignment1`.
- Upload this report, code, outputs and screenshots.
- Add at least one meaningful commit per task (do not make only one final commit).
- Replace all placeholders and add your working GitHub URL to the report.
- Be prepared to explain and modify the programs in the viva.
