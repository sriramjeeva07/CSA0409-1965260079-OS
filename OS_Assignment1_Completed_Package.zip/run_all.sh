#!/bin/sh
set -eu
gcc -std=c11 -Wall -Wextra -O2 Task06/copy_file.c -o Task06/copy_file
gcc -std=c11 -Wall -Wextra -O2 Task07/process_shell.c -o Task07/process_shell
gcc -std=c11 -Wall -Wextra -O2 -pthread Task10/process_thread_bench.c -o Task10/process_thread_bench
echo '--- Task 6 ---'
./Task06/copy_file
echo '--- Task 7 ---'
./Task07/process_shell
echo '--- Task 10 ---'
./Task10/process_thread_bench
