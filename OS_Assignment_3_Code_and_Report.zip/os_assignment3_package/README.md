# Operating Systems Assignment 3 – CO3
Student: S. Jeevan
Register Number: 1965260079

Repository name required by brief: `CSA04-1965260079-Assignment3`

## Environment
Record the actual Linux distribution/version and GCC version used on your computer:
- Linux: run `cat /etc/os-release`
- Compiler: run `gcc --version`
- Page size: run `getconf PAGESIZE`

## Compile and run
Compile each C file from its task folder, for example:
```sh
gcc -std=c11 -Wall -Wextra Task02/paging.c -o paging
./paging
gcc -std=c11 -Wall -Wextra Task05/page_replacement.c -o page_replacement
./page_replacement
gcc -std=c11 -Wall -Wextra Task07/memory_lock.c -o memory_lock
./memory_lock 32
```
For Task01:
```sh
cd Task01
gcc -fPIC -shared crypto_demo.c -o libcrypto_demo.so
gcc -std=c11 -Wall -Wextra linking_demo.c -o linking_demo -ldl
LD_LIBRARY_PATH=. ./linking_demo
```
For Task04:
```sh
gcc -std=c11 -Wall -Wextra demand_paging.c -o demand_paging
./demand_paging 256
gcc -std=c11 -Wall -Wextra cow_demo.c -o cow_demo
./cow_demo
```
For Task06 run `sh Task06/disk_commands.sh`; `fdisk` may request administrator permission.

## Task notes
- Task01 demonstrates run-time loading with dlopen/dlsym and memory maps. Add your own `ldd`, `size`, `/usr/bin/time`, and two-process sharing evidence.
- Task02 translates logical addresses using a page table; also compile `paging_2048.c` for the changed page size.
- Task03 demonstrates segment base/limit translation and limit violations.
- Task04 touches allocated pages and demonstrates fork copy-on-write. Collect page-fault and timing evidence on your machine.
- Task05 implements FIFO, LRU and Optimal, including the provided Belady reference string.
- Task06 collects disk, partition and swap information using Linux commands.
- Task07 demonstrates page prefaulting and mlock; actual real-time guarantees require a configured real-time OS/kernel and hardware testing.

## GitHub workflow
Create the repository with the exact required name. Commit each task separately:
```sh
git init
git add Task01 && git commit -m "Complete Task 1 linking and loading"
git add Task02 && git commit -m "Complete Task 2 paging"
# repeat for Task03 ... Task07
git branch -M main
git remote add origin <YOUR_REPOSITORY_URL>
git push -u origin main
```
Replace the placeholder URL with your own repository URL. Do not submit fabricated screenshots or measurements.
