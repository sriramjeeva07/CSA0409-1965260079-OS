Build shared library: gcc -fPIC -shared crypto_demo.c -o libcrypto_demo.so
Build program: gcc -Wall -Wextra linking_demo.c -o linking_demo -ldl
Run: LD_LIBRARY_PATH=. ./linking_demo
Static/dynamic size comparison: gcc linking_demo.c crypto_demo.c -o static_demo; ls -lh static_demo linking_demo
Note: this small demonstration illustrates linking concepts; use a larger real library for meaningful size comparisons.
