#define _GNU_SOURCE
#include <stdio.h>
#include <dlfcn.h>
#include <unistd.h>
#include <stdlib.h>

int main(void) {
    printf("Main program address: %p\n", (void *)&main);
    FILE *fp = fopen("/proc/self/maps", "r");
    if (fp) {
        char line[256];
        puts("First memory-map entries:");
        for (int i = 0; i < 8 && fgets(line, sizeof line, fp); ++i)
            fputs(line, stdout);
        fclose(fp);
    }
    void *h = dlopen("./libcrypto_demo.so", RTLD_NOW);
    if (!h) {
        fprintf(stderr, "dlopen failed: %s\n", dlerror());
        return 1;
    }
    int (*encrypt_demo)(int) = (int (*)(int)) dlsym(h, "encrypt_demo");
    const char *err = dlerror();
    if (err) { fprintf(stderr, "dlsym failed: %s\n", err); dlclose(h); return 1; }
    printf("Library function address: %p\n", (void *)encrypt_demo);
    printf("Demo result: %d\n", encrypt_demo(42));
    dlclose(h);
    return 0;
}