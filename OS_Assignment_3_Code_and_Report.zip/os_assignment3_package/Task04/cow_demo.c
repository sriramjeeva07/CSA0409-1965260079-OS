#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#define MB (1024*1024)
int main(void) {
    size_t n=64*MB;
    char *p=malloc(n); if(!p){perror("malloc");return 1;}
    for(size_t i=0;i<n;i+=4096)p[i]=1;
    pid_t pid=fork();
    if(pid<0){perror("fork");return 1;}
    if(pid==0){for(size_t i=0;i<n;i+=4096)p[i]=2; puts("Child wrote to its pages (copy-on-write)."); _exit(0);}
    wait(NULL); puts("Parent retained its original pages."); free(p);
}