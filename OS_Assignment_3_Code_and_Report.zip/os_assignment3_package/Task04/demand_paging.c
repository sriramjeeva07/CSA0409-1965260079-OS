#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <sys/resource.h>
#include <sys/wait.h>
#include <unistd.h>
#define MB (1024UL*1024UL)
int main(int argc,char **argv) {
    size_t mb = argc>1 ? strtoul(argv[1],NULL,10) : 256;
    volatile unsigned char *p = calloc(mb, MB);
    if(!p){perror("calloc"); return 1;}
    for(size_t i=0;i<mb*MB;i+=4096) p[i]=(unsigned char)i;
    struct rusage r; getrusage(RUSAGE_SELF,&r);
    printf("Touched %zu MB; minor faults=%ld major faults=%ld max RSS=%ld KB\n",
           mb,r.ru_minflt,r.ru_majflt,r.ru_maxrss);
    free((void*)p);
    return 0;
}