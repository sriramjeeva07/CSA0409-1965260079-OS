#include <stdio.h>
typedef struct { unsigned base, limit; } Segment;
int main(void) {
    Segment s[] = {{1000,500},{4000,1000},{8000,700}};
    unsigned seg[]={0,1,2,1,0,2,1,3};
    unsigned off[]={100,999,699,1001,499,700,0,10};
    for(int i=0;i<8;i++) {
        unsigned n=seg[i], d=off[i];
        if(n>=3) printf("(%u,%u): invalid segment\n",n,d);
        else if(d>=s[n].limit) printf("(%u,%u): protection fault (limit exceeded)\n",n,d);
        else printf("(%u,%u): physical %u\n",n,d,s[n].base+d);
    }
}