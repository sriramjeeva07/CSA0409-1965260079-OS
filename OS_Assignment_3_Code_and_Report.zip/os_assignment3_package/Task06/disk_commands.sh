#!/bin/sh
echo "Block devices and partitions:"
lsblk
echo "Partition table (may require administrator permission):"
sudo fdisk -l
echo "Swap status:"
swapon --show
echo "Filesystem usage:"
df -h