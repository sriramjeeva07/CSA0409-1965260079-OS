#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
#define MB (1024*1024)
static long long ns(struct timespec a,struct timespec b){
 return (b.tv_sec-a.tv_sec)*1000000000LL+(b.tv_nsec-a.tv_nsec);
}
int main(int argc,char **argv){
 size_t mb=argc>1?strtoul(argv[1],NULL,10):32, n=mb*MB;
 char *p=malloc(n);if(!p){perror("malloc");return 1;}
 for(size_t i=0;i<n;i+=4096)p[i]=0; /* prefault pages */
 if(mlock(p,n)!=0)perror("mlock (may need a higher memlock limit)");
 struct timespec a,b; long long worst=0;
 for(int i=0;i<10000;i++){
  clock_gettime(CLOCK_MONOTONIC,&a);
  p[((size_t)i*4096)%n]++;
  clock_gettime(CLOCK_MONOTONIC,&b);
  long long d=ns(a,b);if(d>worst)worst=d;
 }
 printf("Memory=%zu MB, observed worst loop access interval=%lld ns\n",mb,worst);
 munlock(p,n);free(p);return 0;
}