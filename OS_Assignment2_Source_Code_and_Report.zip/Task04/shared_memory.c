#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <semaphore.h>

#define COUNT 6
typedef struct { sem_t ready; int values[COUNT]; } shared_data;
int main(void){
    shared_data *s=mmap(NULL,sizeof(*s),PROT_READ|PROT_WRITE,MAP_SHARED|MAP_ANONYMOUS,-1,0);
    if(s==MAP_FAILED){perror("mmap");return 1;}
    if(sem_init(&s->ready,1,0)==-1){perror("sem_init");return 1;}
    pid_t pid=fork();if(pid<0){perror("fork");return 1;}
    if(pid==0){
        sem_wait(&s->ready);int sum=0,max=s->values[0];
        for(int i=0;i<COUNT;i++){sum+=s->values[i];if(s->values[i]>max)max=s->values[i];}
        printf("shared-memory analyser: %d readings, average %.1f, max %d\n",COUNT,(double)sum/COUNT,max);
        fflush(stdout);_exit(0);
    }
    int v[COUNT]={31,33,36,34,41,38};
    for(int i=0;i<COUNT;i++)s->values[i]=v[i];
    sem_post(&s->ready);waitpid(pid,NULL,0);
    puts("reader: done");sem_destroy(&s->ready);munmap(s,sizeof(*s));return 0;
}
