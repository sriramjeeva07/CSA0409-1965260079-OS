# Operating Systems Assignment 2 – CO2

**Student:** S. Jeevan  
**Register Number:** 1965260079  
**Repository name:** `CSA04-1965260079-Assignment2`

## Environment
- Linux distribution/version: **Fill in the distribution you actually used**
- GCC version: run `gcc --version` and record the output
- GitHub URL: **Replace with your actual repository URL**

## Compile commands
Run from the repository root:

```bash
gcc -std=c11 -Wall -Wextra Task01/process_demo.c -o process_demo
gcc -std=c11 -Wall -Wextra Task02/round_robin.c -o round_robin
gcc -std=c11 -Wall -Wextra -pthread Task03/thread_pool.c -o thread_pool
gcc -std=c11 -Wall -Wextra Task04/pipe_ipc.c -o pipe_ipc
gcc -std=c11 -Wall -Wextra -D_DEFAULT_SOURCE -pthread Task04/shared_memory.c -o shared_memory
gcc -std=c11 -Wall -Wextra -pthread Task05/producer_consumer.c -o producer_consumer
gcc -std=c11 -Wall -Wextra Task06/banker.c -o banker
```

## Run commands
```bash
./process_demo
./round_robin
./thread_pool 1
./thread_pool 4
./thread_pool 8
./thread_pool 16
./pipe_ipc
./shared_memory
./producer_consumer
./banker
```

## Task summary
- **Task01:** Creates child processes with `fork()`; inspect PIDs with `ps` and `/proc`.
- **Task02:** Implements Round Robin for the assignment's four processes and quantum 3.
- **Task03:** Uses a configurable pthread worker pool to process 64 simulated camera workloads.
- **Task04:** Demonstrates pipe IPC and shared-memory IPC with a process-shared semaphore.
- **Task05:** Implements a bounded producer-consumer buffer using semaphores and a mutex.
- **Task06:** Implements the Banker's safety check and resource-request algorithm.

## Evidence still to add
1. Add terminal screenshots for every program.
2. Record your actual Linux and GCC versions.
3. Run the thread-pool measurements and fill in the measured speed-ups.
4. Run the IPC transfer-size experiment (1 MB, 10 MB, 100 MB) and fill in the timings.
5. Run the synchronization test 100 times and save terminal output.
6. Benchmark Banker's safety algorithm at 10, 100 and 1,000 processes.
7. Add one meaningful Git commit per task and share the repository with your faculty.

**Important:** The report contains expected results and analysis, but hardware-dependent benchmark tables are intentionally blank. Fill them with measurements from your own computer; do not submit invented measurements or screenshots.
