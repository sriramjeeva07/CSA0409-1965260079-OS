#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void) {
    for (int i = 0; i < 3; ++i) {
        pid_t pid = fork();
        if (pid < 0) { perror("fork"); return 1; }
        if (pid == 0) {
            printf("child %d: PID=%ld PPID=%ld\n", i + 1, (long)getpid(), (long)getppid());
            sleep(2);
            _exit(0);
        }
    }
    printf("parent PID=%ld; inspect with: ps -o pid,ppid,stat,cmd --ppid %ld\n",
           (long)getpid(), (long)getpid());
    for (int i = 0; i < 3; ++i) wait(NULL);
    puts("parent: all children finished");
    return 0;
}
