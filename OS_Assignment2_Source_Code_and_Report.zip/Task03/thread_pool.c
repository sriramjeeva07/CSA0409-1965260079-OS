#define _POSIX_C_SOURCE 200809L
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define CAMERAS 64
#define WORK 3000000L
static long long results[CAMERAS];
static int next_camera=0;
static pthread_mutex_t mutex=PTHREAD_MUTEX_INITIALIZER;

static void *worker(void *unused) {
    (void)unused;
    for (;;) {
        pthread_mutex_lock(&mutex);
        int id=next_camera++;
        pthread_mutex_unlock(&mutex);
        if(id>=CAMERAS) break;
        unsigned long long x=0;
        for(long i=0;i<WORK;i++) x=(x*33u)+(unsigned long long)(i+id);
        results[id]=(long long)(x & 0x7fffffff);
    }
    return NULL;
}
int main(int argc,char **argv) {
    int n=argc>1?atoi(argv[1]):4;
    if(n<1||n>CAMERAS){fprintf(stderr,"usage: %s [1..64 threads]\n",argv[0]);return 1;}
    pthread_t th[CAMERAS];
    struct timespec a,b; clock_gettime(CLOCK_MONOTONIC,&a);
    for(int i=0;i<n;i++) if(pthread_create(&th[i],NULL,worker,NULL)!=0){perror("pthread_create");return 1;}
    for(int i=0;i<n;i++) pthread_join(th[i],NULL);
    clock_gettime(CLOCK_MONOTONIC,&b);
    double elapsed=(b.tv_sec-a.tv_sec)+(b.tv_nsec-a.tv_nsec)/1e9;
    long long checksum=0;for(int i=0;i<CAMERAS;i++)checksum+=results[i];
    printf("threads=%d cameras=%d elapsed=%.6f seconds checksum=%lld\n",n,CAMERAS,elapsed,checksum);
    return 0;
}
